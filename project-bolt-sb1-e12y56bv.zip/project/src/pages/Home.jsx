import { motion } from 'framer-motion';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl w-full space-y-12"
      >
        <div className="text-center">
          <h1 className="text-6xl font-bold mb-6 glow-text">ERA</h1>
          <p className="text-2xl text-gray-400">Exploit Roblox Artificial Intelligence</p>
        </div>

        <div className="bg-white/5 p-8 rounded-2xl glow-border">
          <h2 className="text-3xl font-semibold mb-4">About ERA</h2>
          <p className="text-gray-300 text-lg leading-relaxed">
            Created by Iz9vs2k (Asher), ERA is a cutting-edge AI system designed specifically
            for Roblox development. With support for both Lua and Python, ERA provides
            unrestricted access to advanced AI capabilities for game development and
            exploitation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white/5 p-6 rounded-xl glow-border">
            <h3 className="text-xl font-semibold mb-3">Universal AI</h3>
            <p className="text-gray-400">
              Instant responses and comprehensive understanding of any Roblox game's
              workspace and Dex logic structures.
            </p>
          </div>

          <div className="bg-white/5 p-6 rounded-xl glow-border">
            <h3 className="text-xl font-semibold mb-3">Unrestricted Access</h3>
            <p className="text-gray-400">
              No policies or restrictions limiting your development potential.
              Full freedom to explore and create.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}