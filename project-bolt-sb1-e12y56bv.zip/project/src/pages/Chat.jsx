import { useState } from 'react';
import { motion } from 'framer-motion';
import { FaPaperPlane } from 'react-icons/fa';
import { CohereClientV2 } from 'cohere-ai';

const cohere = new CohereClientV2({
  token: 'XWGSuqikcPyqKyD0NzlGgrVXlvYmsfip7Tf0e4og',
});

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    
    setIsLoading(true);
    const userMessage = { text: input, sender: 'user' };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    try {
      const response = await cohere.chat({
        model: 'command-r-plus',
        messages: [
          { role: 'user', content: input },
        ],
      });

      setMessages(prev => [...prev, {
        text: response.text,
        sender: 'era'
      }]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        text: "I apologize, but I encountered an error. Please try again.",
        sender: 'era'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex-1 bg-white/5 rounded-t-2xl p-6 overflow-y-auto"
      >
        <div className="space-y-4">
          {messages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] p-4 rounded-xl ${
                  message.sender === 'user'
                    ? 'bg-white/10 glow-border'
                    : 'bg-white/5'
                }`}
              >
                <p className="text-white">{message.text}</p>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="bg-white/5 p-4 rounded-xl">
                <p className="text-white">ERA is thinking...</p>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>

      <form
        onSubmit={handleSubmit}
        className="bg-white/5 rounded-b-2xl p-4 border-t border-white/10"
      >
        <div className="flex space-x-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask ERA anything about Roblox..."
            className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50"
            disabled={isLoading}
          />
          <button
            type="submit"
            className={`bg-white/10 rounded-lg px-6 py-2 text-white transition-colors duration-200 flex items-center space-x-2 ${
              isLoading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-white/20'
            }`}
            disabled={isLoading}
          >
            <FaPaperPlane />
            <span>Send</span>
          </button>
        </div>
      </form>
    </div>
  );
}