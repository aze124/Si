import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FaRobot, FaComment } from 'react-icons/fa';
import Home from './pages/Home';
import Chat from './pages/Chat';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black cyberpunk-grid">
        <nav className="border-b border-white/20 backdrop-blur-sm fixed w-full top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center"
              >
                <Link to="/" className="text-2xl font-bold glow-text">ERA</Link>
              </motion.div>
              <div className="flex space-x-8">
                <Link
                  to="/"
                  className="flex items-center space-x-2 text-white hover:text-gray-300 transition-colors"
                >
                  <FaRobot />
                  <span>Home</span>
                </Link>
                <Link
                  to="/chat"
                  className="flex items-center space-x-2 text-white hover:text-gray-300 transition-colors"
                >
                  <FaComment />
                  <span>Chat</span>
                </Link>
              </div>
            </div>
          </div>
        </nav>

        <div className="pt-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/chat" element={<Chat />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}